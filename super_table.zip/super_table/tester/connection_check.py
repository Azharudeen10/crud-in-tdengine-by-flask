# tester/connection_check.py
from db.connection import get_connection, get_cursor

def test_connection():
    try:
        print("Testing connection...")
        with get_connection() as conn:
            if conn:
                print("Connection successful")
                with get_cursor(conn) as cursor:
                    if cursor:
                        print("Cursor obtained")
                    else:
                        print("Failed to obtain cursor")
            else:
                print("Failed to connect")
    except Exception as e:
        print(f"Test failed: {e}")

test_connection()