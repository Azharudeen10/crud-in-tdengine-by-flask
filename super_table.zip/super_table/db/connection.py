import taos
from db.config import TDENGINE_URI
from contextlib import contextmanager

@contextmanager
def get_connection():
    conn = None
    try:
        conn = taos.connect(TDENGINE_URI, database="sensor_data")
        yield conn
    except Exception as e:
        print(f"Error connecting to TDengine: {e}")
        yield None
    finally:
        if conn:
            conn.close()

@contextmanager
def get_cursor(conn):
    cursor = None
    if conn:
        cursor = conn.cursor()
    try:
        yield cursor
    finally:
        if cursor:
            cursor.close()
