import time
import random
from datetime import datetime
import taos
from db.config import TDENGINE_URI

def get_last_id(conn):
    try:
        query = "SELECT MAX(id) AS last_id FROM device1;"
        result = conn.query(query)
        rows = result.fetch_all()  # Fetch all rows from the result
        if rows:
            last_id = rows[0][0]  # Accessing the first column of the first row
            return last_id if last_id is not None else 0
        return 0
    except Exception as e:
        print(f"Error fetching last ID: {e}")
        return 0

def generate_data(next_id):
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    temperature = round(random.uniform(15.0, 30.0), 2)
    humidity = round(random.uniform(30.0, 60.0), 2)
    rpm = random.randint(1000, 2000)  # Generate a random RPM value
    data_id = next_id  # Use the next available ID
    location = "Coimbatore"  # Location tag
    groupid = "group1"       # Group tag
    return {
        "id": data_id,
        "ts": ts,
        "temperature": temperature,
        "humidity": humidity,
        "rpm": rpm,
        "location": location,
        "groupid": groupid
    }

def create_database_if_not_exists(conn):
    create_database_query = """
    CREATE DATABASE IF NOT EXISTS sensor_data KEEP 365 DURATION 10 BUFFER 16 WAL_LEVEL 1;
    """
    conn.execute(create_database_query)
    print("Database 'sensor_data' ensured to exist.")

def create_supertable_if_not_exists(conn):
    try:
        query = "SHOW STABLES;"
        tables = conn.query(query)
        tables_list = tables.fetch_all()  # Fetch all rows from the result
        if 'super_sensor_table' not in [row[0] for row in tables_list]:
            create_table_query = """
            CREATE STABLE super_sensor_table (
                ts TIMESTAMP ENCODE 'delta-i' COMPRESS 'lz4' LEVEL 'medium',
                temperature DOUBLE ENCODE 'delta-d' COMPRESS 'lz4' LEVEL 'medium',
                humidity DOUBLE ENCODE 'delta-d' COMPRESS 'lz4' LEVEL 'medium',
                id INT ENCODE 'simple8b' COMPRESS 'lz4' LEVEL 'medium',
                rpm INT ENCODE 'simple8b' COMPRESS 'lz4' LEVEL 'medium'
            ) TAGS (location VARCHAR(50), groupid VARCHAR(50));
            """
            conn.execute(create_table_query)
            print("Supertable 'super_sensor_table' created.")
        else:
            print("Supertable 'super_sensor_table' already exists.")
    except Exception as e:
        print(f"Error creating supertable: {e}")

def create_table_if_not_exists(conn):
    try:
        query = "SHOW TABLES;"
        tables = conn.query(query)
        tables_list = tables.fetch_all()  # Fetch all rows from the result
        if 'device1' not in [row[0] for row in tables_list]:
            create_table_query = """
            CREATE TABLE device1 USING super_sensor_table 
            TAGS ('Coimbatore', 'group1');
            """
            conn.execute(create_table_query)
            print("Table 'device1' created.")
        else:
            print("Table 'device1' already exists.")
    except Exception as e:
        print(f"Error creating table: {e}")

def insert_data_into_tdengine(conn, data):
    table_name = "device1"
    create_table_if_not_exists(conn)  # Ensure the subtable 'device1' exists

    query = f"""
    INSERT INTO {table_name} (ts, temperature, humidity, id, rpm)
    VALUES ('{data['ts']}', {data['temperature']}, {data['humidity']}, {data['id']}, {data['rpm']});
    """
    try:
        conn.execute(query)
        print(f"Data inserted into TDengine: {data}")
    except Exception as e:
        print(f"Failed to insert data: {e}")

def main():
    try:
        conn = taos.connect(TDENGINE_URI)
        create_database_if_not_exists(conn)
        conn.close()
        conn = taos.connect(TDENGINE_URI, database="sensor_data")
        create_supertable_if_not_exists(conn)

        last_id = get_last_id(conn)
        next_id = last_id + 1

        while True:
            data = generate_data(next_id)
            insert_data_into_tdengine(conn, data)
            next_id += 1
            time.sleep(5)

    except KeyboardInterrupt:
        print("Process interrupted by user. Exiting gracefully...")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        conn.close()
        print("TDengine connection closed.")

if __name__ == "__main__":
    main()
