from flask import request, jsonify
from db.connection import get_connection, get_cursor
from db.queries import (
    get_columns_query,
    insert_entry_query,
    read_entries_query,
    update_entry_query,
    delete_by_timestamp_query,
)
from tester.count_entries_test import count_entries
from datetime import datetime, timedelta

ROUTE_PATH = '/data'

def get_columns():
    """Retrieve column names from the database."""
    with get_connection() as conn:
        with get_cursor(conn) as cursor:
            cursor.execute(get_columns_query())
            columns = [row[0] for row in cursor.fetchall()]
    return columns

def create_entry():
    """Create a new entry in the database."""
    data = request.json
    columns = get_columns()

    # Define which fields are tags and which are columns
    tag_fields = ['location', 'groupid']
    data_columns = [col for col in columns if col in data and col not in tag_fields]
    tags = {tag: data.get(tag) for tag in tag_fields if tag in data}

    # Check for missing required fields
    required_columns = columns
    missing_fields = [col for col in required_columns if col not in data]
    if missing_fields:
        return jsonify({"error": f"Missing required fields: {', '.join(missing_fields)}"}), 400

    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)
    tags_str = ', '.join(f'"{tags[tag]}"' for tag in tag_fields if tag in tags)

    query = insert_entry_query(values_str, tags_str)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def read_entries():
    """Read entries from the database with optional filters."""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    offset = (page - 1) * per_page
    limit = per_page

    try:
        total_count = count_entries()
        if total_count is None:
            return jsonify({"error": "Failed to count entries from the database."}), 500

        if offset >= total_count:
            max_page = (total_count + per_page - 1) // per_page
            return jsonify({
                "warning": f"The requested page exceeds the available data range. Total available entries: {total_count}. Maximum allowed page: {max_page} with per_page: {per_page}."
            }), 400

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                columns = get_columns()
                query = read_entries_query(timestamp_str, start_timestamp, end_timestamp, limit, offset)
                cursor.execute(query)
                results = cursor.fetchall()

                formatted_results = []
                for row in results:
                    entry = {}
                    for col, value in zip(columns, row):
                        if col == 'ts':
                            entry['timestamp'] = value.strftime('%Y-%m-%d %H:%M:%S') if isinstance(value, datetime) else value
                        else:
                            entry[col] = value
                    formatted_results.append(entry)

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

def update_entry():
    """Update an existing entry in the database (overwrite)."""
    data = request.json
    entry_id = data.get('id')

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    try:
        columns_str = 'ts, temperature, humidity, id, rpm'
        values_str = f"'{data['ts']}', {data['temperature']}, {data['humidity']}, {data['id']}, {data['rpm']}"
        query = update_entry_query(columns_str, values_str)

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def delete_by_timestamp():
    """Delete entries within a specified timestamp range."""
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        query = delete_by_timestamp_query(from_timestamp.strftime('%Y-%m-%d %H:%M:%S'), to_timestamp.strftime('%Y-%m-%d %H:%M:%S'))

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def init_routes(app):
    """Initialize API routes for the Flask app."""
    app.route(ROUTE_PATH, methods=['POST'])(create_entry)
    app.route(ROUTE_PATH, methods=['GET'])(read_entries)
    app.route(ROUTE_PATH, methods=['PUT'])(update_entry)
    app.route(ROUTE_PATH, methods=['DELETE'])(delete_by_timestamp)
