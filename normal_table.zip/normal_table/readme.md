# Task3 Project

task3/normal_table
├── controllers/
│   ├── __init__.py
│   ├── app.py
│   └── routes.py
├── db/
│   ├── __init__.py
│   ├── config.py
│   └── connection.py
├── models/
│   └── data_generation.py
└── myenv/
└── Dockerfile
└── docker-compose.yml
└── requirements.txt

## Overview

This project is a Flask application that interacts with a TDengine database. The application includes functionality for creating, reading, updating, and deleting entries. Finally we do dockerize that.

## Getting Started

To get started, follow these steps:

1. **Clone the Repository**

   ```bash
   git clone <repository_url>
   cd task3/normal_table
   docker compose --build
   docker compose up -d
   python3 controllers/app.py


   #then you can check with api working in postman and data changes in dbeaver