# from flask import Flask, request, jsonify
# from db.connection import get_connection, get_cursor
# from datetime import datetime, timedelta

# app = Flask(__name__)

# # Create an entry
# def create_entry():
#     data = request.json
#     timestamp = data.get('timestamp')
#     temperature = data.get('temperature')
#     humidity = data.get('humidity')
#     entry_id = data.get('id')
#     deleted = data.get('deleted', 0)  # Default to 0 if not provided

#     if not all([timestamp, temperature, humidity, entry_id]):
#         return jsonify({"error": "Missing required fields"}), 400

#     try:
#         with get_connection() as conn:
#             if conn:
#                 with get_cursor(conn) as cursor:
#                     query = f"""
#                     INSERT INTO d1001 (ts, temperature, humidity, id, deleted) 
#                     VALUES ('{timestamp}', {temperature}, {humidity}, '{entry_id}', {deleted})
#                     """
#                     cursor.execute(query)
#                     conn.commit()
#         return jsonify({"message": "Entry created successfully"}), 201
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Read all entries

# def read_entries():
#     page = request.args.get('page', 1, type=int)
#     per_page = request.args.get('per_page', 10, type=int)

#     # Calculate offset and limit
#     offset = (page - 1) * per_page
#     limit = per_page

#     try:
#         with get_connection() as conn:
#             if not conn:
#                 return jsonify({"error": "Failed to connect to the database."}), 500

#             with get_cursor(conn) as cursor:
#                 # Query with pagination
#                 query = f"""
#                 SELECT * FROM d1001 
#                 WHERE deleted = 0
#                 LIMIT {limit} OFFSET {offset}
#                 """
#                 cursor.execute(query)
#                 results = cursor.fetchall()

#                 formatted_results = []
#                 for row in results:
#                     timestamp = row[0]
#                     # Format timestamp to a readable string
#                     timestamp_str = timestamp.strftime('%Y-%m-%d %H:%M:%S') if isinstance(timestamp, datetime) else timestamp
#                     formatted_results.append({
#                         "timestamp": timestamp_str,
#                         "temperature": row[1],
#                         "humidity": row[2],
#                         "id": row[3]
#                     })

#                 return jsonify(formatted_results), 200

#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


# # Update an entry
# def update_entry():
#     data = request.json
#     entry_id = data.get('id')
#     temperature = data.get('temperature')
#     humidity = data.get('humidity')
#     timestamp = data.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))  # Default to current time if not provided

#     if not entry_id:
#         return jsonify({"error": "ID is required for update"}), 400

#     try:
#         with get_connection() as conn:
#             if conn:
#                 with get_cursor(conn) as cursor:
#                     query = f"""
#                     INSERT INTO d1001 (ts, temperature, humidity, id, deleted) 
#                     VALUES ('{timestamp}', {temperature}, {humidity}, '{entry_id}', 0)
#                     """
#                     cursor.execute(query)
#                     conn.commit()
#         return jsonify({"message": "Entry updated successfully"}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Delete by timestamp range
# def delete_by_timestamp():
#     timestamp_str = request.args.get('timestamp')
    
#     if not timestamp_str:
#         return jsonify({"error": "Timestamp is required"}), 400

#     try:
#         from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
#         to_timestamp = from_timestamp + timedelta(seconds=1)

#         with get_connection() as conn:
#             if conn:
#                 with get_cursor(conn) as cursor:
#                     query = f"""
#                     DELETE FROM d1001 
#                     WHERE ts >= '{from_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
#                       AND ts < '{to_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
#                     """
#                     cursor.execute(query)
#                     conn.commit()
#         return jsonify({"message": "Entries deleted successfully."}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Initialize routes for the Flask app
# def init_routes(app):
#     app.route('/data', methods=['POST'])(create_entry)
#     app.route('/data', methods=['GET'])(read_entries)
#     app.route('/data', methods=['PUT'])(update_entry)  
#     app.route('/data', methods=['DELETE'])(delete_by_timestamp)

# # Initialize routes
# init_routes(app)

# if __name__ == '__main__':
#     app.run(debug=True)




#Modified to get the data from the range and individual
'''
from flask import Flask, request, jsonify
from db.connection import get_connection, get_cursor
from datetime import datetime, timedelta

app = Flask(__name__)

# Create an entry
def create_entry():
    data = request.json
    timestamp = data.get('timestamp')
    temperature = data.get('temperature')
    humidity = data.get('humidity')
    entry_id = data.get('id')
    deleted = data.get('deleted', 0)  # Default to 0 if not provided

    if not all([timestamp, temperature, humidity, entry_id]):
        return jsonify({"error": "Missing required fields"}), 400

    try:
        with get_connection() as conn:
            if conn:
                with get_cursor(conn) as cursor:
                    query = f"""
                    INSERT INTO d1001 (ts, temperature, humidity, id, deleted) 
                    VALUES ('{timestamp}', {temperature}, {humidity}, '{entry_id}', {deleted})
                    """
                    cursor.execute(query)
                    conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Read entries with optional timestamp filtering
def read_entries():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    # Calculate offset and limit for pagination
    offset = (page - 1) * per_page
    limit = per_page

    try:
        with get_connection() as conn:
            if not conn:
                return jsonify({"error": "Failed to connect to the database."}), 500

            with get_cursor(conn) as cursor:
                if timestamp_str:
                    # Fetch individual record by timestamp
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts = '{timestamp_str}' AND deleted = 0
                    """
                elif start_timestamp and end_timestamp:
                    # Fetch records within the specified range
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts BETWEEN '{start_timestamp}' AND '{end_timestamp}' AND deleted = 0
                    """
                else:
                    # Fetch paginated records
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE deleted = 0
                    LIMIT {limit} OFFSET {offset}
                    """
                
                cursor.execute(query)
                results = cursor.fetchall()

                formatted_results = []
                for row in results:
                    timestamp = row[0]
                    # Format timestamp to a readable string
                    timestamp_str = timestamp.strftime('%Y-%m-%d %H:%M:%S') if isinstance(timestamp, datetime) else timestamp
                    formatted_results.append({
                        "timestamp": timestamp_str,
                        "temperature": row[1],
                        "humidity": row[2],
                        "id": row[3]
                    })

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Update an entry
def update_entry():
    data = request.json
    entry_id = data.get('id')
    temperature = data.get('temperature')
    humidity = data.get('humidity')
    timestamp = data.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))  # Default to current time if not provided

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    try:
        with get_connection() as conn:
            if conn:
                with get_cursor(conn) as cursor:
                    query = f"""
                    INSERT INTO d1001 (ts, temperature, humidity, id, deleted) 
                    VALUES ('{timestamp}', {temperature}, {humidity}, '{entry_id}', 0)
                    """
                    cursor.execute(query)
                    conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Delete by timestamp range
def delete_by_timestamp():
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        with get_connection() as conn:
            if conn:
                with get_cursor(conn) as cursor:
                    query = f"""
                    DELETE FROM d1001 
                    WHERE ts >= '{from_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                      AND ts < '{to_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                    """
                    cursor.execute(query)
                    conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Initialize routes for the Flask app
def init_routes(app):
    app.route('/data', methods=['POST'])(create_entry)
    app.route('/data', methods=['GET'])(read_entries)
    app.route('/data', methods=['PUT'])(update_entry)  
    app.route('/data', methods=['DELETE'])(delete_by_timestamp)

# Initialize routes
init_routes(app)

if __name__ == '__main__':
    app.run(debug=True)
'''




#untouched code

'''
from flask import Flask, request, jsonify
from db.connection import get_connection, get_cursor
from datetime import datetime, timedelta

app = Flask(__name__)

# Get column names dynamically
def get_columns():
    with get_connection() as conn:
        with get_cursor(conn) as cursor:
            cursor.execute("DESCRIBE d1001")
            columns = [row[0] for row in cursor.fetchall()]
    return columns

# Create an entry
def create_entry():
    data = request.json
    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    if not all([col in data for col in columns if col != 'deleted']):
        return jsonify({"error": "Missing required fields"}), 400

    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"INSERT INTO d1001 ({columns_str}) VALUES ({values_str})"
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Read entries with optional timestamp filtering
def read_entries():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    # Calculate offset and limit for pagination
    offset = (page - 1) * per_page
    limit = per_page

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                if timestamp_str:
                    # Fetch individual record by timestamp
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts = '{timestamp_str}' AND deleted = 0
                    """
                elif start_timestamp and end_timestamp:
                    # Fetch records within the specified range
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts BETWEEN '{start_timestamp}' AND '{end_timestamp}' AND deleted = 0
                    """
                else:
                    # Fetch paginated records
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE deleted = 0
                    LIMIT {limit} OFFSET {offset}
                    """
                
                cursor.execute(query)
                results = cursor.fetchall()

                columns = get_columns()
                formatted_results = []
                for row in results:
                    entry = {}
                    for col, value in zip(columns, row):
                        if col == 'ts':
                            # Format timestamp to a readable string
                            entry['timestamp'] = value.strftime('%Y-%m-%d %H:%M:%S') if isinstance(value, datetime) else value
                        else:
                            entry[col] = value
                    formatted_results.append(entry)

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Update an entry
def update_entry():
    data = request.json
    entry_id = data.get('id')
    columns = get_columns()

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    data_columns = [col for col in columns if col in data]
    set_str = ', '.join(f"{col} = '{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"""
                UPDATE d1001 
                SET {set_str} 
                WHERE id = '{entry_id}' AND deleted = 0
                """
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Delete by timestamp range
def delete_by_timestamp():
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"""
                DELETE FROM d1001 
                WHERE ts >= '{from_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                  AND ts < '{to_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                """
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Initialize routes for the Flask app
def init_routes(app):
    app.route('/data', methods=['POST'])(create_entry)
    app.route('/data', methods=['GET'])(read_entries)
    app.route('/data', methods=['PUT'])(update_entry)  
    app.route('/data', methods=['DELETE'])(delete_by_timestamp)

# Initialize routes
init_routes(app)

if __name__ == '__main__':
    app.run(debug=True)
'''


#modified untouched code pwc
'''
from flask import Flask, request, jsonify
from db.connection import get_connection, get_cursor
from datetime import datetime, timedelta

app = Flask(__name__)

# Get column names dynamically
def get_columns():
    with get_connection() as conn:
        with get_cursor(conn) as cursor:
            cursor.execute("DESCRIBE d1001")
            columns = [row[0] for row in cursor.fetchall()]
    return columns

# Create an entry
def create_entry():
    data = request.json
    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Check for missing required fields, excluding 'deleted'
    required_columns = [col for col in columns if col != 'deleted']
    if not all(col in data for col in required_columns):
        missing_fields = [col for col in required_columns if col not in data]
        return jsonify({"error": f"Missing required fields: {', '.join(missing_fields)}"}), 400

    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"INSERT INTO d1001 ({columns_str}) VALUES ({values_str})"
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Read entries with optional timestamp filtering
def read_entries():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    # Calculate offset and limit for pagination
    offset = (page - 1) * per_page
    limit = per_page

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                columns = get_columns()
                if timestamp_str:
                    # Fetch individual record by timestamp
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts = '{timestamp_str}' AND deleted = 0
                    """
                elif start_timestamp and end_timestamp:
                    # Fetch records within the specified range
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE ts BETWEEN '{start_timestamp}' AND '{end_timestamp}' AND deleted = 0
                    """
                else:
                    # Fetch paginated records
                    query = f"""
                    SELECT * FROM d1001 
                    WHERE deleted = 0
                    LIMIT {limit} OFFSET {offset}
                    """
                
                cursor.execute(query)
                results = cursor.fetchall()

                formatted_results = []
                for row in results:
                    entry = {}
                    for col, value in zip(columns, row):
                        if col == 'ts':
                            # Format timestamp to a readable string
                            entry['timestamp'] = value.strftime('%Y-%m-%d %H:%M:%S') if isinstance(value, datetime) else value
                        else:
                            entry[col] = value
                    formatted_results.append(entry)

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Update an entry
def update_entry():
    data = request.json
    entry_id = data.get('id')

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Construct the column names and values for the query
    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"""
                INSERT INTO d1001 ({columns_str}) 
                VALUES ({values_str})
                """
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# Delete by timestamp range
def delete_by_timestamp():
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = f"""
                DELETE FROM d1001 
                WHERE ts >= '{from_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                  AND ts < '{to_timestamp.strftime('%Y-%m-%d %H:%M:%S')}'
                """
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Initialize routes for the Flask app
def init_routes(app):
    app.route('/data', methods=['POST'])(create_entry)
    app.route('/data', methods=['GET'])(read_entries)
    app.route('/data', methods=['PUT'])(update_entry)  
    app.route('/data', methods=['DELETE'])(delete_by_timestamp)

# Initialize routes
init_routes(app)

if __name__ == '__main__':
    app.run(debug=True)
'''


# controllers/routes.py 
# query seperated 
'''
from flask import Flask, request, jsonify
from db.connection import get_connection, get_cursor
from db.queries import (
    get_columns_query,
    insert_entry_query,
    read_entries_query,
    update_entry_query,
    delete_by_timestamp_query,
)
from datetime import datetime, timedelta

app = Flask(__name__)

# Get column names dynamically
def get_columns():
    with get_connection() as conn:
        with get_cursor(conn) as cursor:
            cursor.execute(get_columns_query())
            columns = [row[0] for row in cursor.fetchall()]
    return columns

# Create an entry
def create_entry():
    data = request.json
    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Check for missing required fields
    required_columns = columns  # No 'deleted' column
    if not all(col in data for col in required_columns):
        missing_fields = [col for col in required_columns if col not in data]
        return jsonify({"error": f"Missing required fields: {', '.join(missing_fields)}"}), 400

    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = insert_entry_query(columns_str, values_str)
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Read entries with optional timestamp filtering
def read_entries():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    # Calculate offset and limit for pagination
    offset = (page - 1) * per_page
    limit = per_page

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                columns = get_columns()
                query = read_entries_query(timestamp_str, start_timestamp, end_timestamp, limit, offset)
                
                cursor.execute(query)
                results = cursor.fetchall()

                formatted_results = []
                for row in results:
                    entry = {}
                    for col, value in zip(columns, row):
                        if col == 'ts':
                            # Format timestamp to a readable string
                            entry['timestamp'] = value.strftime('%Y-%m-%d %H:%M:%S') if isinstance(value, datetime) else value
                        else:
                            entry[col] = value
                    formatted_results.append(entry)

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Update an entry
def update_entry():
    data = request.json
    entry_id = data.get('id')

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Construct the column names and values for the query
    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = update_entry_query(columns_str, values_str)
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Delete by timestamp range
def delete_by_timestamp():
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = delete_by_timestamp_query(from_timestamp.strftime('%Y-%m-%d %H:%M:%S'), to_timestamp.strftime('%Y-%m-%d %H:%M:%S'))
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Initialize routes for the Flask app
def init_routes(app):
    app.route('/data', methods=['POST'])(create_entry)
    app.route('/data', methods=['GET'])(read_entries)
    app.route('/data', methods=['PUT'])(update_entry)  
    app.route('/data', methods=['DELETE'])(delete_by_timestamp)

# Initialize routes
init_routes(app)

if __name__ == '__main__':
    app.run(debug=True)
    '''
    
    
# for per page limit
from flask import request, jsonify
from db.connection import get_connection, get_cursor
from db.queries import (
    get_columns_query,
    insert_entry_query,
    read_entries_query,
    update_entry_query,
    delete_by_timestamp_query,
)
from tester.count_entries_test import count_entries
from datetime import datetime, timedelta
ROUTE_PATH = '/data'
# Get column names dynamically
def get_columns():
    with get_connection() as conn:
        with get_cursor(conn) as cursor:
            cursor.execute(get_columns_query())
            columns = [row[0] for row in cursor.fetchall()]
    return columns

# Create an entry
def create_entry():
    data = request.json
    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Check for missing required fields
    required_columns = columns  # No 'deleted' column
    if not all(col in data for col in required_columns):
        missing_fields = [col for col in required_columns if col not in data]
        return jsonify({"error": f"Missing required fields: {', '.join(missing_fields)}"}), 400

    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = insert_entry_query(columns_str, values_str)
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Read entries with optional timestamp filtering
def read_entries():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    timestamp_str = request.args.get('timestamp')
    start_timestamp = request.args.get('start')
    end_timestamp = request.args.get('end')

    # Calculate offset and limit for pagination
    offset = (page - 1) * per_page
    limit = per_page

    try:
        # Count entries to diagnose the issue directly in the Flask app
        total_count = count_entries()  # Ensure this is imported and used correctly
        if total_count is None:
            return jsonify({"error": "Failed to count entries from the database."}), 500

        # Check if the requested page exceeds the available data range
        if offset >= total_count:
            max_page = (total_count + per_page - 1) // per_page  # Calculate the max available page number
            return jsonify({
                "warning": f"The requested page exceeds the available data range. Total available entries: {total_count}. Maximum allowed page: {max_page} with per_page: {per_page}."
            }), 400

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                columns = get_columns()
                query = read_entries_query(timestamp_str, start_timestamp, end_timestamp, limit, offset)
                cursor.execute(query)
                results = cursor.fetchall()

                formatted_results = []
                for row in results:
                    entry = {}
                    for col, value in zip(columns, row):
                        if col == 'ts':
                            # Format timestamp to a readable string
                            entry['timestamp'] = value.strftime('%Y-%m-%d %H:%M:%S') if isinstance(value, datetime) else value
                        else:
                            entry[col] = value
                    formatted_results.append(entry)

                return jsonify(formatted_results), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Update an entry
def update_entry():
    data = request.json
    entry_id = data.get('id')

    if not entry_id:
        return jsonify({"error": "ID is required for update"}), 400

    columns = get_columns()
    data_columns = [col for col in columns if col in data]

    # Construct the column names and values for the query
    columns_str = ', '.join(data_columns)
    values_str = ', '.join(f"'{data.get(col)}'" for col in data_columns)

    try:
        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = update_entry_query(columns_str, values_str)
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entry updated successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Delete by timestamp range
def delete_by_timestamp():
    timestamp_str = request.args.get('timestamp')
    
    if not timestamp_str:
        return jsonify({"error": "Timestamp is required"}), 400

    try:
        from_timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        to_timestamp = from_timestamp + timedelta(seconds=1)

        with get_connection() as conn:
            with get_cursor(conn) as cursor:
                query = delete_by_timestamp_query(from_timestamp.strftime('%Y-%m-%d %H:%M:%S'), to_timestamp.strftime('%Y-%m-%d %H:%M:%S'))
                cursor.execute(query)
                conn.commit()
        return jsonify({"message": "Entries deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Initialize routes for the Flask app
def init_routes(app):
    #ROUTE_PATH = '/data'
    app.route(ROUTE_PATH, methods=['POST'])(create_entry)
    app.route(ROUTE_PATH, methods=['GET'])(read_entries)
    app.route(ROUTE_PATH, methods=['PUT'])(update_entry)  
    app.route(ROUTE_PATH, methods=['DELETE'])(delete_by_timestamp)