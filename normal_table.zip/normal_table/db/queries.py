def get_columns_query():
    return "DESCRIBE d1001"

def insert_entry_query(columns_str, values_str):
    return f"INSERT INTO d1001 ({columns_str}) VALUES ({values_str})"

def read_entries_query(timestamp_str=None, start_timestamp=None, end_timestamp=None, limit=10, offset=0):
    if timestamp_str:
        return f"""
        SELECT * FROM d1001 
        WHERE ts = '{timestamp_str}'
        LIMIT {limit} OFFSET {offset}
        """
    elif start_timestamp and end_timestamp:
        return f"""
        SELECT * FROM d1001 
        WHERE ts BETWEEN '{start_timestamp}' AND '{end_timestamp}'
        LIMIT {limit} OFFSET {offset}
        """
    else:
        return f"""
        SELECT * FROM d1001 
        LIMIT {limit} OFFSET {offset}
        """

def update_entry_query(columns_str, values_str):
    return f"""
    INSERT INTO d1001 ({columns_str}) 
    VALUES ({values_str})
    """

def delete_by_timestamp_query(from_timestamp, to_timestamp):
    return f"""
    DELETE FROM d1001 
    WHERE ts >= '{from_timestamp}' 
      AND ts < '{to_timestamp}'
    """
