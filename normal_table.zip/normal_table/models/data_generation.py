import time
import random
from datetime import datetime
import taos
from db.config import TDENGINE_URI

# Function to generate data with a unique integer ID
def generate_data():
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    temperature = round(random.uniform(15.0, 30.0), 2)
    humidity = round(random.uniform(30.0, 60.0), 2)
    rpm = random.randint(1000, 2000)  # Generate a random RPM value
    data_id = random.randint(1, 9223372036854775807)  # Generate a random integer within BIGINT range
    return {"id": data_id, "ts": ts, "temperature": temperature, "humidity": humidity, "rpm": rpm}

# Function to create the database if it doesn't exist
def create_database_if_not_exists(conn):
    create_database_query = """
    CREATE DATABASE IF NOT EXISTS sensor_data KEEP 365 DURATION 10 BUFFER 16 WAL_LEVEL 1;
    """
    conn.execute(create_database_query)
    print("Database 'sensor_data' ensured to exist.")

# Function to create a specific table if it doesn't exist
def create_table_if_not_exists(conn):
    create_table_query = """
    CREATE TABLE IF NOT EXISTS d1001 (
        ts TIMESTAMP,
        temperature DOUBLE,
        humidity DOUBLE,
        id BIGINT,
        rpm INT
    );
    """
    conn.execute(create_table_query)
    print("Table 'd1001' ensured to exist.")

# Function to insert data into TDengine
def insert_data_into_tdengine(conn, data):
    query = f"""
    INSERT INTO d1001 (ts, temperature, humidity, id, rpm)
    VALUES ('{data['ts']}', {data['temperature']}, {data['humidity']}, {data['id']}, {data['rpm']})
    """
    try:
        conn.execute(query)
        print(f"Data inserted into TDengine: {data}")
    except Exception as e:
        print(f"Failed to insert data: {e}")

def main():
    # Connect to TDengine without specifying the database
    try:
        conn = taos.connect(TDENGINE_URI)
        create_database_if_not_exists(conn)
    except Exception as e:
        print(f"Error connecting to TDengine: {e}")
        return

    try:
        # Reconnect with the database specified
        conn.close()
        conn = taos.connect(TDENGINE_URI, database="sensor_data")
        create_table_if_not_exists(conn)

        # Continuously generate and insert data
        while True:
            data = generate_data()
            insert_data_into_tdengine(conn, data)
            time.sleep(5)

    except KeyboardInterrupt:
        print("Process interrupted by user. Exiting gracefully...")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        # Ensure the connection to TDengine is closed properly
        conn.close()
        print("TDengine connection closed.")

if __name__ == "__main__":
    main()
