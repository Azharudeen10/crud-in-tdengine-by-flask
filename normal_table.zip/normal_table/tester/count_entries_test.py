from db.connection import get_connection, get_cursor

def count_entries():
    count_query = "SELECT COUNT(*) FROM d1001"

    with get_connection() as conn:
        if conn is None:
            print("No connection to TDengine.")
            return
        
        with get_cursor(conn) as cursor:
            if cursor is None:
                print("No cursor created.")
                return
            
            try:
                cursor.execute(count_query)
                results = cursor.fetchall()
                
                if results and len(results) > 0:
                    count = results[0][0]  # Extracting the count from the first row and column
                    print(f"Total entries count: {count}")
                    return count
                else:
                    print("No results fetched from the count query.")
                    return 0
            except Exception as e:
                print(f"Error executing count query: {e}")
                return 0

if __name__ == "__main__":
    count_entries()